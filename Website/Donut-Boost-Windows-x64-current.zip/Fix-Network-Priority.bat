@echo off
:: Batch script to auto-elevate and prioritize Wi-Fi over USB Tethering
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo Requesting Administrator privileges...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

echo ========================================================
echo   Donut Boost - Network Priority ^& Wi-Fi Fixer
echo ========================================================
echo.
echo [1/4] Prioritizing Wi-Fi as Primary Connection (Metric 5)...
powershell -NoProfile -Command "Get-NetIPInterface -AddressFamily IPv4 | Where-Object { $_.InterfaceAlias -like '*Wi-Fi*' -or $_.InterfaceAlias -like '*Wireless*' -or $_.InterfaceAlias -like '*WLAN*' } | Set-NetIPInterface -InterfaceMetric 5 -ErrorAction SilentlyContinue"

echo [2/4] Setting Ethernet and Phone Tethering adapters to Background (Metric 60)...
powershell -NoProfile -Command "Get-NetIPInterface -AddressFamily IPv4 | Where-Object { $_.InterfaceAlias -notlike '*Wi-Fi*' -and $_.InterfaceAlias -notlike '*Wireless*' -and $_.InterfaceAlias -notlike '*WLAN*' -and $_.InterfaceAlias -notlike '*Loopback*' } | Set-NetIPInterface -InterfaceMetric 60 -ErrorAction SilentlyContinue"

echo [3/4] Resetting Windows Proxy Settings...
powershell -NoProfile -Command "Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -Name ProxyEnable -Value 0"

echo [4/4] Flushing DNS Cache...
ipconfig /flushdns >nul

echo.
echo ========================================================
echo   SUCCESS! 
echo   - Laptop will now stay 100%% on Home Wi-Fi
echo   - Taskbar will always show the Wi-Fi icon (never Ethernet)
echo   - Donut Boost will bond Phone 5G/4G to boost downloads!
echo ========================================================
echo.
pause
