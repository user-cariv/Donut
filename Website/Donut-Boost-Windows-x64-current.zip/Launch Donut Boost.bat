@echo off
cd /d "%~dp0"
if exist "DonutBoost.exe" (
    start "" "DonutBoost.exe"
) else (
    dotnet "DonutBoost.dll"
)
